package interp;

public class EmptyEnv extends Env {
}

