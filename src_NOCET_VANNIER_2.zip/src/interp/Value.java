package interp;

public abstract class Value {
}
