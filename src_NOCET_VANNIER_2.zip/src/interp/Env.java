package interp;

public abstract class Env {
}
